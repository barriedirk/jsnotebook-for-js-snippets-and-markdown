// The easy way to run the app npx jbook serve

// import express

// one route
// serve up react production assets

// Save a list of cells into a file

// Load up a list of cells from a file

// express server listet on port 4050
